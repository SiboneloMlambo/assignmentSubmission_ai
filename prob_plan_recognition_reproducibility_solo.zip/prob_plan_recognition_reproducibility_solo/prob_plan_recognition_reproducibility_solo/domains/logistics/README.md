# Logistics Goal Recognition — Publication-Level Reproducibility Repo

This repo is the Logistics-domain version of the Blocksworld goal-recognition pipeline.
It includes:

- A typed `logistics.pddl` domain.
- A working Logistics problem instance.
- Candidate delivery goals.
- A deterministic built-in Logistics planner, so the project runs even without Fast Downward.
- Bayesian goal recognition with explicit beta experimentation.
- Observation-percentage experiments.
- Missing, corrupt, spurious, and mixed noise experiments.
- CSV outputs and publication-style plots.
- A LaTeX report skeleton.

## Run a single goal-recognition example

```bash
python full_pipeline.py --mode single --beta 1.0
```

## Run the full publication experiment

```bash
python full_pipeline.py --mode publication --runs 50
```

Outputs are written to:

```text
outputs/publication_raw_candidates.csv
outputs/publication_trials.csv
outputs/publication_summary.csv
outputs/plots/
```

## Fast Downward

The repo does not require Fast Downward because it contains a small deterministic Logistics planner.
If your marker requires a planner path, you can still pass:

```bash
python full_pipeline.py --fd-path "C:/path/to/fast-downward.py"
```

If the path is invalid, the code falls back to the built-in planner.

## Core problem

Initial state:

- `package1` starts at `locA2`.
- `package2` starts at `locB2`.
- `truckA` starts at `locA1`.
- `truckB` starts at `locB1`.
- `plane1` starts at `airportA`.

Main true goal:

```lisp
(and
  (at package1 locB1)
  (at package2 locA1)
)
```

This requires city-level truck movement plus inter-city airplane transport.
