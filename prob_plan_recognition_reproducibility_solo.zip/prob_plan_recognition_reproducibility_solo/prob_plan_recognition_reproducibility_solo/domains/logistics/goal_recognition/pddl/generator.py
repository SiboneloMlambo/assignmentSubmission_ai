from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations
from typing import FrozenSet, Iterable, List

from goal_recognition.pddl.parser import Fact


@dataclass(frozen=True)
class CandidateGoal:
    name: str
    facts: FrozenSet[Fact]


def generate_delivery_goals(packages: Iterable[str], destinations: Iterable[str], max_goals: int | None = None) -> List[CandidateGoal]:
    """Generate candidate Logistics goals by assigning packages to destination locations."""
    pkg_list = list(packages)
    dest_list = list(destinations)
    goals: List[CandidateGoal] = []
    for dest_order in permutations(dest_list, len(pkg_list)):
        facts = frozenset(("at", (p, d)) for p, d in zip(pkg_list, dest_order))
        name = "deliver_" + "__".join(f"{p}_to_{d}" for p, d in zip(pkg_list, dest_order))
        goals.append(CandidateGoal(name=name, facts=facts))
        if max_goals is not None and len(goals) >= max_goals:
            break
    return goals


def default_logistics_goals() -> List[CandidateGoal]:
    return [
        CandidateGoal("G1_swap_city_packages", frozenset({("at", ("package1", "locB1")), ("at", ("package2", "locA1"))})),
        CandidateGoal("G2_package1_to_locB2_package2_to_locA2", frozenset({("at", ("package1", "locB2")), ("at", ("package2", "locA2"))})),
        CandidateGoal("G3_package1_to_airportB_package2_to_airportA", frozenset({("at", ("package1", "airportB")), ("at", ("package2", "airportA"))})),
        CandidateGoal("G4_package1_to_locB1_package2_to_airportA", frozenset({("at", ("package1", "locB1")), ("at", ("package2", "airportA"))})),
    ]
