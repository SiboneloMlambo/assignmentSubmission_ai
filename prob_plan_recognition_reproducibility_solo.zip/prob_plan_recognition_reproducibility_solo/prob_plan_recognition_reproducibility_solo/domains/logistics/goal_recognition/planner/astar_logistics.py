from __future__ import annotations

from dataclasses import dataclass, field
from typing import FrozenSet, Iterable, List, Optional, Set

from goal_recognition.pddl.parser import Fact, State
from goal_recognition.observation.loader import Action


@dataclass(order=True)
class Node:
    priority: int
    cost: int
    state: State = field(compare=False)
    plan: List[Action] = field(compare=False, default_factory=list)


class LogisticsAStarPlanner:
    """Fast deterministic Logistics planner for reproducible goal-recognition experiments."""

    def __init__(self, packages: Iterable[str], trucks: Iterable[str], airplanes: Iterable[str], locations: Iterable[str], airports: Iterable[str], cities: Iterable[str], max_expansions: int = 100000):
        self.packages = tuple(packages)
        self.trucks = tuple(trucks)
        self.airplanes = tuple(airplanes)
        self.locations = tuple(locations)
        self.airports = tuple(airports)
        self.cities = tuple(cities)
        self.max_expansions = max_expansions

    def is_goal(self, state: State, goal: FrozenSet[Fact]) -> bool:
        return goal.issubset(state)

    def _in_city(self, state: State, loc: str, city: str) -> bool:
        return ("in-city", (loc, city)) in state

    def applicable_actions(self, state: State) -> List[Action]:
        actions: List[Action] = []
        for p in self.packages:
            for t in self.trucks:
                for l in self.locations:
                    if ("at", (p, l)) in state and ("at", (t, l)) in state:
                        actions.append(("load-truck", (p, t, l)))
                    if ("in", (p, t)) in state and ("at", (t, l)) in state:
                        actions.append(("unload-truck", (p, t, l)))
        for t in self.trucks:
            for frm in self.locations:
                if ("at", (t, frm)) not in state:
                    continue
                for to in self.locations:
                    if frm == to:
                        continue
                    for c in self.cities:
                        if self._in_city(state, frm, c) and self._in_city(state, to, c):
                            actions.append(("drive-truck", (t, frm, to, c)))
                            break
        for p in self.packages:
            for a in self.airplanes:
                for ap in self.airports:
                    if ("at", (p, ap)) in state and ("at", (a, ap)) in state:
                        actions.append(("load-airplane", (p, a, ap)))
                    if ("in", (p, a)) in state and ("at", (a, ap)) in state:
                        actions.append(("unload-airplane", (p, a, ap)))
        for a in self.airplanes:
            for frm in self.airports:
                if ("at", (a, frm)) not in state:
                    continue
                for to in self.airports:
                    if frm != to:
                        actions.append(("fly-airplane", (a, frm, to)))
        return actions

    def apply(self, state: State, action: Action) -> Optional[State]:
        name, args = action
        s: Set[Fact] = set(state)
        def has(f: Fact) -> bool: return f in s
        def add(f: Fact) -> None: s.add(f)
        def rem(f: Fact) -> None: s.discard(f)
        if name == "load-truck":
            p, t, l = args
            if not (has(("at", (p, l))) and has(("at", (t, l)))): return None
            rem(("at", (p, l))); add(("in", (p, t)))
        elif name == "unload-truck":
            p, t, l = args
            if not (has(("in", (p, t))) and has(("at", (t, l)))): return None
            rem(("in", (p, t))); add(("at", (p, l)))
        elif name == "drive-truck":
            t, frm, to, c = args
            if not (has(("at", (t, frm))) and has(("in-city", (frm, c))) and has(("in-city", (to, c)))): return None
            rem(("at", (t, frm))); add(("at", (t, to)))
        elif name == "load-airplane":
            p, a, ap = args
            if not (has(("at", (p, ap))) and has(("at", (a, ap)))): return None
            rem(("at", (p, ap))); add(("in", (p, a)))
        elif name == "unload-airplane":
            p, a, ap = args
            if not (has(("in", (p, a))) and has(("at", (a, ap)))): return None
            rem(("in", (p, a))); add(("at", (p, ap)))
        elif name == "fly-airplane":
            a, frm, to = args
            if not has(("at", (a, frm))): return None
            rem(("at", (a, frm))); add(("at", (a, to)))
        else:
            return None
        return frozenset(s)

    def replay(self, init: State, observations: List[Action]) -> Optional[State]:
        state = init
        for action in observations:
            state = self.apply(state, action)
            if state is None:
                return None
        return state

    def _loc_city(self, state: State, loc: str) -> str | None:
        for c in self.cities:
            if ("in-city", (loc, c)) in state:
                return c
        return None

    def _airport_for_city(self, state: State, city: str) -> str | None:
        for ap in self.airports:
            if ("in-city", (ap, city)) in state:
                return ap
        return None

    def _object_location(self, state: State, obj: str) -> str | None:
        for pred, args in state:
            if pred == "at" and len(args) == 2 and args[0] == obj:
                return args[1]
        return None

    def _truck_for_city(self, state: State, city: str) -> str | None:
        for t in self.trucks:
            loc = self._object_location(state, t)
            if loc and self._loc_city(state, loc) == city:
                return t
        return None

    def _append(self, state: State, plan: List[Action], action: Action) -> State | None:
        nxt = self.apply(state, action)
        if nxt is None:
            return None
        plan.append(action)
        return nxt

    def _move_truck(self, state: State, plan: List[Action], truck: str, dest: str) -> State | None:
        cur = self._object_location(state, truck)
        if cur == dest:
            return state
        city = self._loc_city(state, cur) if cur else None
        if city is None or self._loc_city(state, dest) != city:
            return None
        return self._append(state, plan, ("drive-truck", (truck, cur, dest, city)))

    def _move_plane(self, state: State, plan: List[Action], airport: str) -> State | None:
        plane = self.airplanes[0]
        cur = self._object_location(state, plane)
        if cur == airport:
            return state
        if cur is None:
            return None
        return self._append(state, plan, ("fly-airplane", (plane, cur, airport)))

    def _deliver_at_package(self, state: State, plan: List[Action], package: str, dest: str) -> State | None:
        src = self._object_location(state, package)
        if src == dest:
            return state
        if src is None:
            return None
        src_city, dest_city = self._loc_city(state, src), self._loc_city(state, dest)
        if src_city is None or dest_city is None:
            return None
        if src_city == dest_city:
            truck = self._truck_for_city(state, src_city)
            if truck is None: return None
            state = self._move_truck(state, plan, truck, src)
            if state is None: return None
            state = self._append(state, plan, ("load-truck", (package, truck, src)))
            if state is None: return None
            state = self._move_truck(state, plan, truck, dest)
            if state is None: return None
            return self._append(state, plan, ("unload-truck", (package, truck, dest)))
        src_airport = self._airport_for_city(state, src_city)
        dest_airport = self._airport_for_city(state, dest_city)
        if src_airport is None or dest_airport is None: return None
        truck = self._truck_for_city(state, src_city)
        if truck is None: return None
        state = self._move_truck(state, plan, truck, src)
        if state is None: return None
        state = self._append(state, plan, ("load-truck", (package, truck, src)))
        if state is None: return None
        state = self._move_truck(state, plan, truck, src_airport)
        if state is None: return None
        state = self._append(state, plan, ("unload-truck", (package, truck, src_airport)))
        if state is None: return None
        state = self._move_plane(state, plan, src_airport)
        if state is None: return None
        plane = self.airplanes[0]
        state = self._append(state, plan, ("load-airplane", (package, plane, src_airport)))
        if state is None: return None
        state = self._move_plane(state, plan, dest_airport)
        if state is None: return None
        state = self._append(state, plan, ("unload-airplane", (package, plane, dest_airport)))
        if state is None: return None
        if dest == dest_airport:
            return state
        dest_truck = self._truck_for_city(state, dest_city)
        if dest_truck is None: return None
        state = self._move_truck(state, plan, dest_truck, dest_airport)
        if state is None: return None
        state = self._append(state, plan, ("load-truck", (package, dest_truck, dest_airport)))
        if state is None: return None
        state = self._move_truck(state, plan, dest_truck, dest)
        if state is None: return None
        return self._append(state, plan, ("unload-truck", (package, dest_truck, dest)))

    def plan(self, init: State, goal: FrozenSet[Fact]) -> Optional[List[Action]]:
        state = init
        plan: List[Action] = []
        if self.is_goal(state, goal):
            return plan
        for pred, args in sorted(goal):
            if pred == "at" and len(args) == 2 and args[0] in self.packages:
                state = self._deliver_at_package(state, plan, args[0], args[1])
                if state is None:
                    return None
        return plan if self.is_goal(state, goal) else None

    def plan_cost(self, init: State, goal: FrozenSet[Fact]) -> float:
        plan = self.plan(init, goal)
        return float("inf") if plan is None else float(len(plan))
