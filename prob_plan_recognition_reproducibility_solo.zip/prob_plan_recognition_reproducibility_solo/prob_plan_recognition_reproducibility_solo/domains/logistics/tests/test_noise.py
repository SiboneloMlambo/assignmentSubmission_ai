import random

from goal_recognition.observation.noise import apply_executable_noise
from goal_recognition.pddl.generator import default_logistics_goals
from goal_recognition.pddl.parser import parse_problem
from full_pipeline import build_default_logistics_planner


def test_noise_trace_is_executable():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = build_default_logistics_planner()
    plan = planner.plan(problem["init"], default_logistics_goals()[0].facts)
    assert plan is not None
    noisy = apply_executable_noise(plan[:5], problem["init"], planner, random.Random(1), mode="mixed", rate=0.3)
    assert planner.replay(problem["init"], noisy.observations) is not None
