from goal_recognition.bayes.scorer import BayesianGoalScorer
from goal_recognition.pddl.generator import default_logistics_goals
from goal_recognition.pddl.parser import parse_problem
from goal_recognition.planner.astar_logistics import LogisticsAStarPlanner
from full_pipeline import build_default_logistics_planner


def test_logistics_goals_are_solvable():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = build_default_logistics_planner()
    for goal in default_logistics_goals():
        assert planner.plan(problem["init"], goal.facts) is not None


def test_bayesian_scorer_returns_probabilities():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = build_default_logistics_planner()
    goals = default_logistics_goals()
    scorer = BayesianGoalScorer(planner, beta=1.0)
    scores = scorer.score(problem["init"], [], goals)
    assert len(scores) == len(goals)
    assert abs(sum(s.probability for s in scores) - 1.0) < 1e-9
