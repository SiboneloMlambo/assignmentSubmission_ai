(define (domain logistics)
  (:requirements :strips :typing)
  (:types package truck airplane location airport city - object)
  (:predicates
    (at ?x - object ?l - location)
    (in ?p - package ?v - object)
    (in-city ?l - location ?c - city)
  )

  (:action load-truck
    :parameters (?p - package ?t - truck ?l - location)
    :precondition (and (at ?p ?l) (at ?t ?l))
    :effect (and (not (at ?p ?l)) (in ?p ?t)))

  (:action unload-truck
    :parameters (?p - package ?t - truck ?l - location)
    :precondition (and (in ?p ?t) (at ?t ?l))
    :effect (and (not (in ?p ?t)) (at ?p ?l)))

  (:action drive-truck
    :parameters (?t - truck ?from - location ?to - location ?c - city)
    :precondition (and (at ?t ?from) (in-city ?from ?c) (in-city ?to ?c))
    :effect (and (not (at ?t ?from)) (at ?t ?to)))

  (:action load-airplane
    :parameters (?p - package ?a - airplane ?ap - airport)
    :precondition (and (at ?p ?ap) (at ?a ?ap))
    :effect (and (not (at ?p ?ap)) (in ?p ?a)))

  (:action unload-airplane
    :parameters (?p - package ?a - airplane ?ap - airport)
    :precondition (and (in ?p ?a) (at ?a ?ap))
    :effect (and (not (in ?p ?a)) (at ?p ?ap)))

  (:action fly-airplane
    :parameters (?a - airplane ?from - airport ?to - airport)
    :precondition (at ?a ?from)
    :effect (and (not (at ?a ?from)) (at ?a ?to)))
)
