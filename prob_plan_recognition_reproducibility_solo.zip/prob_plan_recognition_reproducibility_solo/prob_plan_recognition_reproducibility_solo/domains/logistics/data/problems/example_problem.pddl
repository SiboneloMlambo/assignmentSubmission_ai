(define (problem logistics-goal-recognition-01)
  (:domain logistics)
  (:objects
    package1 package2 - package
    truckA truckB - truck
    plane1 - airplane
    locA1 locA2 airportA locB1 locB2 airportB - location
    cityA cityB - city
  )
  (:init
    (in-city locA1 cityA)
    (in-city locA2 cityA)
    (in-city airportA cityA)
    (in-city locB1 cityB)
    (in-city locB2 cityB)
    (in-city airportB cityB)
    (at truckA locA1)
    (at truckB locB1)
    (at plane1 airportA)
    (at package1 locA2)
    (at package2 locB2)
  )
  (:goal
    (and
      (at package1 locB1)
      (at package2 locA1)
    )
  )
)
