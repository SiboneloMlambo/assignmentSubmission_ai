from goal_recognition.bayes.scorer import BayesianGoalScorer
from goal_recognition.pddl.generator import generate_stack_goals
from goal_recognition.pddl.parser import parse_problem
from goal_recognition.planner.astar_blocksworld import BlocksworldAStarPlanner


def test_probabilities_sum_to_one():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = BlocksworldAStarPlanner(problem["objects"])
    goals = generate_stack_goals(problem["objects"])
    scorer = BayesianGoalScorer(planner, beta=1.0)
    scores = scorer.score(problem["init"], [], goals)
    assert abs(sum(s.probability for s in scores) - 1.0) < 1e-9


def test_beta_changes_confidence_when_deltas_differ():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = BlocksworldAStarPlanner(problem["objects"])
    goals = generate_stack_goals(problem["objects"])
    plan = planner.plan(problem["init"], goals[0].facts)
    observations = plan[:2]
    low = BayesianGoalScorer(planner, beta=0.1).score(problem["init"], observations, goals)[0].probability
    high = BayesianGoalScorer(planner, beta=10).score(problem["init"], observations, goals)[0].probability
    assert high >= low
