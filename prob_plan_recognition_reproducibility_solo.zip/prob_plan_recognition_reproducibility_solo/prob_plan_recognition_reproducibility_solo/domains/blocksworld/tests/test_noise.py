from goal_recognition.observation.noise import apply_executable_noise
from goal_recognition.pddl.parser import parse_problem
from goal_recognition.pddl.generator import generate_stack_goals
from goal_recognition.planner.astar_blocksworld import BlocksworldAStarPlanner
import random


def test_noise_keeps_trace_executable():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = BlocksworldAStarPlanner(problem["objects"])
    goal = generate_stack_goals(problem["objects"], max_goals=1)[0]
    plan = planner.plan(problem["init"], goal.facts)
    noisy = apply_executable_noise(plan, problem["init"], planner, random.Random(1), mode="mixed", rate=0.3)
    assert planner.replay(problem["init"], noisy.observations) is not None
    assert noisy.original_length == len(plan)
