# Blocksworld Goal Recognition Reproducibility Repo

This repository is a compact reproduction pipeline for Ramirez & Geffner's probabilistic plan-recognition method, focused on the Blocksworld/Block Words setting.

It includes the core reproduction plus publication-level extensions requested in the assignment brief:

- Bayesian goal scoring with an explicit beta parameter.
- Beta sensitivity analysis.
- Multiple repeated trials with fixed random seeds.
- Observation-percentage experiments.
- Observation noise robustness: missing, corrupted, spurious, and mixed observations.
- Trial-level, candidate-level, and summary CSV outputs.
- 95% confidence intervals for top-1 accuracy.
- Report-ready plots and LaTeX text.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Fast Downward is optional for this educational Blocksworld pipeline. The repo includes a deterministic built-in Blocksworld BFS planner so that the experiments run without external planner setup. If you install Fast Downward, pass its path using `--fd-path`.

## Single recognition run

```bash
python full_pipeline.py --mode single --beta 1.0
```

Output:

```text
outputs/ranked_goals.csv
```

## Publication-level experiment

```bash
python full_pipeline.py \
  --mode publication \
  --runs 50 \
  --betas 0.1,0.25,0.5,1,2,5,10 \
  --observation-percentages 0.25,0.5,0.75,1.0 \
  --noise-rates 0,0.1,0.2,0.3 \
  --noise-modes none,missing,corrupt,spurious,mixed
```

Outputs:

```text
outputs/publication_raw_candidates.csv   # one row per candidate goal per condition
outputs/publication_trials.csv           # one row per trial per condition
outputs/publication_summary.csv          # grouped means, SDs, and 95% confidence intervals
outputs/plots/*.png                      # report-ready figures and heatmaps
```

## Noise modes

The noise module keeps traces executable so that the downstream scorer measures robustness instead of failing on impossible action sequences.

- `none`: clean observations.
- `missing`: observed actions are dropped with probability `noise_rate`.
- `corrupt`: observed actions are replaced by another applicable action with probability `noise_rate`.
- `spurious`: extra applicable actions are inserted with probability `noise_rate`.
- `mixed`: combines missing, corrupted, and spurious noise.

## Important assignment justification

The assignment brief notes that the original paper does not specify beta, so this repo treats beta as an experimental variable. It also includes noise robustness as an extension beyond the direct reproduction.

## Tests

```bash
pytest
```

## Recommended report claims

Suggested testable claims:

1. Increasing observation percentage improves top-1 goal recognition accuracy.
2. Beta controls posterior sharpness; higher beta gives more confident distributions but may be less robust under noise.
3. Observation noise reduces accuracy, with mixed noise being the most damaging.
4. The method is reproducible on small Blocksworld instances, but exact reproduction of the original paper is limited by underspecified beta and implementation details.
