from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Optional


class FastDownwardPlanner:
    """Thin wrapper around Fast Downward.

    This wrapper is optional. The main repo uses the built-in A* planner by default so
    the project runs even when Fast Downward is not installed.
    """

    def __init__(self, fd_path: str | None = None, timeout: int = 60):
        self.fd_path = Path(fd_path) if fd_path else None
        self.timeout = timeout

    def available(self) -> bool:
        return self.fd_path is not None and self.fd_path.exists()

    def run(self, domain_file: str, problem_file: str) -> subprocess.CompletedProcess[str]:
        if not self.available():
            raise FileNotFoundError(
                "Fast Downward path is missing. Pass --fd-path /path/to/fast-downward.py "
                "or use the built-in A* planner."
            )
        cmd = ["python", str(self.fd_path), domain_file, problem_file, "--search", "astar(lmcut())"]
        return subprocess.run(cmd, text=True, capture_output=True, timeout=self.timeout, check=False)
