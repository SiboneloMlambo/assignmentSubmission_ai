from __future__ import annotations

from dataclasses import dataclass, field
from heapq import heappop, heappush
from itertools import permutations
from typing import FrozenSet, Iterable, List, Optional, Set

from goal_recognition.pddl.parser import Fact, State
from goal_recognition.observation.loader import Action


@dataclass(order=True)
class Node:
    priority: int
    cost: int
    state: State = field(compare=False)
    plan: List[Action] = field(compare=False, default_factory=list)


class BlocksworldAStarPlanner:
    """Small deterministic A* planner for reproducible Blocksworld experiments."""

    def __init__(self, blocks: Iterable[str], max_expansions: int = 50000):
        self.blocks = tuple(blocks)
        self.max_expansions = max_expansions

    def heuristic(self, state: State, goal: FrozenSet[Fact]) -> int:
        return sum(1 for fact in goal if fact not in state)

    def is_goal(self, state: State, goal: FrozenSet[Fact]) -> bool:
        return goal.issubset(state)

    def applicable_actions(self, state: State) -> List[Action]:
        actions: List[Action] = []
        handempty = ("handempty", tuple()) in state
        for x in self.blocks:
            if ("clear", (x,)) in state and ("ontable", (x,)) in state and handempty:
                actions.append(("pick-up", (x,)))
            if ("holding", (x,)) in state:
                actions.append(("put-down", (x,)))
        for x, y in permutations(self.blocks, 2):
            if ("on", (x, y)) in state and ("clear", (x,)) in state and handempty:
                actions.append(("unstack", (x, y)))
            if ("holding", (x,)) in state and ("clear", (y,)) in state:
                actions.append(("stack", (x, y)))
        return actions

    def apply(self, state: State, action: Action) -> Optional[State]:
        name, args = action
        s: Set[Fact] = set(state)

        def has(f: Fact) -> bool:
            return f in s

        def add(f: Fact) -> None:
            s.add(f)

        def rem(f: Fact) -> None:
            s.discard(f)

        if name == "pick-up":
            (x,) = args
            if not (has(("clear", (x,))) and has(("ontable", (x,))) and has(("handempty", tuple()))):
                return None
            add(("holding", (x,)))
            rem(("ontable", (x,)))
            rem(("clear", (x,)))
            rem(("handempty", tuple()))
        elif name == "put-down":
            (x,) = args
            if not has(("holding", (x,))):
                return None
            add(("ontable", (x,)))
            add(("clear", (x,)))
            add(("handempty", tuple()))
            rem(("holding", (x,)))
        elif name == "stack":
            x, y = args
            if not (has(("holding", (x,))) and has(("clear", (y,)))):
                return None
            add(("on", (x, y)))
            add(("clear", (x,)))
            add(("handempty", tuple()))
            rem(("holding", (x,)))
            rem(("clear", (y,)))
        elif name == "unstack":
            x, y = args
            if not (has(("on", (x, y))) and has(("clear", (x,))) and has(("handempty", tuple()))):
                return None
            add(("holding", (x,)))
            add(("clear", (y,)))
            rem(("on", (x, y)))
            rem(("clear", (x,)))
            rem(("handempty", tuple()))
        else:
            return None
        return frozenset(s)

    def replay(self, init: State, observations: List[Action]) -> Optional[State]:
        state = init
        for action in observations:
            nxt = self.apply(state, action)
            if nxt is None:
                return None
            state = nxt
        return state

    def plan(self, init: State, goal: FrozenSet[Fact]) -> Optional[List[Action]]:
        """Return one lowest-cost plan, or None if search fails.

        The reproduction domains are intentionally small, so deterministic breadth-first
        search is sufficient and avoids heuristic/tie-breaking artefacts across systems.
        """
        from collections import deque

        if self.is_goal(init, goal):
            return []
        queue = deque([(init, [])])
        visited = {init}
        expansions = 0
        while queue and expansions < self.max_expansions:
            state, plan = queue.popleft()
            expansions += 1
            for action in self.applicable_actions(state):
                nxt = self.apply(state, action)
                if nxt is None or nxt in visited:
                    continue
                next_plan = plan + [action]
                if self.is_goal(nxt, goal):
                    return next_plan
                visited.add(nxt)
                queue.append((nxt, next_plan))
        return None

    def plan_cost(self, init: State, goal: FrozenSet[Fact]) -> float:
        plan = self.plan(init, goal)
        return float("inf") if plan is None else float(len(plan))
