from __future__ import annotations

from pathlib import Path

import pandas as pd


def write_plots(summary_df: pd.DataFrame, output_dir: str | Path = "outputs/plots") -> list[Path]:
    """Create report-ready plots from the publication summary CSV."""
    import matplotlib.pyplot as plt

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []

    clean = summary_df[(summary_df["noise_mode"] == "none") & (summary_df["noise_rate"] == 0.0)]
    if not clean.empty:
        for metric, ylabel, filename in [
            ("accuracy", "Top-1 accuracy", "clean_accuracy_vs_beta.png"),
            ("mean_true_goal_probability", "Mean probability assigned to true goal", "clean_true_goal_probability_vs_beta.png"),
            ("mean_true_goal_rank", "Mean true-goal rank", "clean_true_goal_rank_vs_beta.png"),
        ]:
            fig, ax = plt.subplots(figsize=(8, 5))
            for obs_pct, group in clean.groupby("observation_percentage"):
                group = group.sort_values("beta")
                yerr = None
                if metric == "accuracy":
                    yerr = group["accuracy_ci95_half_width"]
                ax.errorbar(group["beta"], group[metric], yerr=yerr, marker="o", capsize=3, label=f"{int(obs_pct * 100)}% obs")
            ax.set_xscale("log")
            ax.set_xlabel("Beta")
            ax.set_ylabel(ylabel)
            ax.set_title(ylabel + " vs beta, clean observations")
            ax.grid(True, alpha=0.3)
            ax.legend()
            fig.tight_layout()
            path = out / filename
            fig.savefig(path, dpi=200)
            plt.close(fig)
            paths.append(path)

    noisy = summary_df[summary_df["noise_mode"] != "none"]
    if not noisy.empty:
        for obs_pct, obs_group in noisy.groupby("observation_percentage"):
            fig, ax = plt.subplots(figsize=(8, 5))
            for (mode, rate), group in obs_group.groupby(["noise_mode", "noise_rate"]):
                group = group.sort_values("beta")
                ax.errorbar(
                    group["beta"],
                    group["accuracy"],
                    yerr=group["accuracy_ci95_half_width"],
                    marker="o",
                    capsize=3,
                    label=f"{mode}, rate={rate:g}",
                )
            ax.set_xscale("log")
            ax.set_xlabel("Beta")
            ax.set_ylabel("Top-1 accuracy")
            ax.set_title(f"Noise robustness at {int(obs_pct * 100)}% observation")
            ax.grid(True, alpha=0.3)
            ax.legend(fontsize=8)
            fig.tight_layout()
            path = out / f"noise_accuracy_vs_beta_obs_{int(obs_pct * 100)}.png"
            fig.savefig(path, dpi=200)
            plt.close(fig)
            paths.append(path)

        # Heatmaps for each noise mode at the highest observation percentage.
        max_obs = max(noisy["observation_percentage"])
        for mode, mode_group in noisy[noisy["observation_percentage"] == max_obs].groupby("noise_mode"):
            pivot = mode_group.pivot_table(index="noise_rate", columns="beta", values="accuracy", aggfunc="mean")
            if pivot.empty:
                continue
            fig, ax = plt.subplots(figsize=(8, 4.8))
            im = ax.imshow(pivot.values, aspect="auto", origin="lower")
            ax.set_xticks(range(len(pivot.columns)))
            ax.set_xticklabels([f"{c:g}" for c in pivot.columns])
            ax.set_yticks(range(len(pivot.index)))
            ax.set_yticklabels([f"{i:g}" for i in pivot.index])
            ax.set_xlabel("Beta")
            ax.set_ylabel("Noise rate")
            ax.set_title(f"Accuracy heatmap: {mode} noise at {int(max_obs * 100)}% observation")
            for i in range(len(pivot.index)):
                for j in range(len(pivot.columns)):
                    ax.text(j, i, f"{pivot.values[i, j]:.2f}", ha="center", va="center", fontsize=8)
            fig.colorbar(im, ax=ax, label="Top-1 accuracy")
            fig.tight_layout()
            path = out / f"heatmap_{mode}_noise_accuracy.png"
            fig.savefig(path, dpi=200)
            plt.close(fig)
            paths.append(path)

    return paths
