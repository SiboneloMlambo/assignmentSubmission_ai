from __future__ import annotations

from dataclasses import dataclass
import math
import random
from typing import Iterable, List, Sequence

import pandas as pd

from goal_recognition.bayes.scorer import BayesianGoalScorer
from goal_recognition.pddl.generator import CandidateGoal
from goal_recognition.pddl.parser import State
from goal_recognition.observation.loader import Action
from goal_recognition.observation.noise import NoiseMode, apply_executable_noise
from goal_recognition.planner.astar_blocksworld import BlocksworldAStarPlanner


@dataclass
class ExperimentResult:
    predicted_goal: str
    true_goal: str
    true_goal_rank: int
    top1_correct: bool
    table: pd.DataFrame


def run_single_experiment(
    scorer: BayesianGoalScorer,
    init: State,
    observations: List[Action],
    goals: List[CandidateGoal],
    true_goal_name: str,
) -> ExperimentResult:
    scores = scorer.score(init, observations, goals)
    rows = []
    for rank, s in enumerate(scores, start=1):
        rows.append({
            "rank": rank,
            "goal": s.goal.name,
            "optimal_cost": s.optimal_cost,
            "compliant_cost": s.compliant_cost,
            "delta": s.delta,
            "log_likelihood": s.log_likelihood,
            "probability": s.probability,
        })
    table = pd.DataFrame(rows)
    predicted = str(table.iloc[0]["goal"])
    match = table.index[table["goal"] == true_goal_name]
    true_rank = int(table.loc[match[0], "rank"]) if len(match) else -1
    return ExperimentResult(
        predicted_goal=predicted,
        true_goal=true_goal_name,
        true_goal_rank=true_rank,
        top1_correct=(predicted == true_goal_name),
        table=table,
    )


def observation_prefix(plan: Sequence[Action], percentage: float) -> List[Action]:
    if percentage <= 0:
        return []
    k = max(1, round(len(plan) * percentage))
    return list(plan[: min(k, len(plan))])


def _normal_ci(mean: float, n: int, z: float = 1.96) -> tuple[float, float]:
    if n <= 0:
        return 0.0, 0.0
    se = math.sqrt(max(mean * (1.0 - mean), 0.0) / n)
    return max(0.0, mean - z * se), min(1.0, mean + z * se)


def _add_ci_columns(summary_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in summary_df.iterrows():
        low, high = _normal_ci(float(row["accuracy"]), int(row["trials"]))
        r = row.to_dict()
        r["accuracy_ci95_low"] = low
        r["accuracy_ci95_high"] = high
        r["accuracy_ci95_half_width"] = (high - low) / 2.0
        rows.append(r)
    return pd.DataFrame(rows)


def run_publication_experiment(
    planner: BlocksworldAStarPlanner,
    init: State,
    goals: List[CandidateGoal],
    betas: Iterable[float],
    observation_percentages: Iterable[float],
    noise_rates: Iterable[float],
    noise_modes: Iterable[NoiseMode],
    runs: int = 50,
    seed: int = 7,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Run beta/observation/noise robustness experiments with repeated trials.

    Returns:
      raw_df: one row per candidate goal for every experimental condition.
      trial_df: one row per trial/condition with top-1, rank, and true-goal probability.
      summary_df: grouped publication-ready means, standard deviations, and 95% CIs.
    """
    rng = random.Random(seed)
    candidate_goals = list(goals)
    betas = [float(b) for b in betas]
    observation_percentages = [float(x) for x in observation_percentages]
    noise_rates = [float(x) for x in noise_rates]
    noise_modes = list(noise_modes)

    raw_rows = []
    trial_rows = []

    solvable_goals = []
    for goal in candidate_goals:
        plan = planner.plan(init, goal.facts)
        if plan is not None:
            solvable_goals.append((goal, plan))

    if not solvable_goals:
        raise RuntimeError("No candidate goals were solvable from the initial state.")

    for run_id in range(1, runs + 1):
        true_goal, full_plan = rng.choice(solvable_goals)
        for obs_pct in observation_percentages:
            clean_obs = observation_prefix(full_plan, obs_pct)
            for noise_mode in noise_modes:
                for noise_rate in noise_rates:
                    if noise_mode == "none" and noise_rate != 0.0:
                        continue
                    if noise_mode != "none" and noise_rate == 0.0:
                        continue
                    noisy = apply_executable_noise(
                        clean_obs,
                        init=init,
                        planner=planner,
                        rng=rng,
                        mode=noise_mode,
                        rate=noise_rate,
                    )
                    for beta in betas:
                        scorer = BayesianGoalScorer(planner=planner, beta=beta)
                        result = run_single_experiment(scorer, init, noisy.observations, candidate_goals, true_goal.name)
                        true_prob_series = result.table.loc[result.table["goal"] == true_goal.name, "probability"]
                        true_prob = float(true_prob_series.iloc[0]) if not true_prob_series.empty else 0.0
                        trial_key = {
                            "run_id": run_id,
                            "seed": seed,
                            "beta": beta,
                            "observation_percentage": obs_pct,
                            "clean_observation_length": len(clean_obs),
                            "noise_mode": noise_mode,
                            "noise_rate": noise_rate,
                            "noisy_observation_length": noisy.noisy_length,
                            "dropped_actions": noisy.dropped,
                            "corrupted_actions": noisy.corrupted,
                            "inserted_actions": noisy.inserted,
                            "true_goal": true_goal.name,
                            "predicted_goal": result.predicted_goal,
                            "top1_correct": bool(result.top1_correct),
                            "true_goal_rank": int(result.true_goal_rank),
                            "true_goal_probability": true_prob,
                        }
                        trial_rows.append(trial_key)
                        for _, row in result.table.iterrows():
                            raw_rows.append({
                                **trial_key,
                                "candidate_goal": row["goal"],
                                "candidate_rank": int(row["rank"]),
                                "optimal_cost": row["optimal_cost"],
                                "compliant_cost": row["compliant_cost"],
                                "delta": row["delta"],
                                "candidate_probability": row["probability"],
                            })

    raw_df = pd.DataFrame(raw_rows)
    trial_df = pd.DataFrame(trial_rows)
    summary_df = (
        trial_df.groupby(["beta", "observation_percentage", "noise_mode", "noise_rate"], as_index=False)
        .agg(
            trials=("run_id", "count"),
            accuracy=("top1_correct", "mean"),
            mean_true_goal_rank=("true_goal_rank", "mean"),
            std_true_goal_rank=("true_goal_rank", "std"),
            mean_true_goal_probability=("true_goal_probability", "mean"),
            std_true_goal_probability=("true_goal_probability", "std"),
            mean_noisy_observation_length=("noisy_observation_length", "mean"),
            mean_dropped_actions=("dropped_actions", "mean"),
            mean_corrupted_actions=("corrupted_actions", "mean"),
            mean_inserted_actions=("inserted_actions", "mean"),
        )
        .sort_values(["observation_percentage", "noise_mode", "noise_rate", "beta"])
    )
    for col in ["std_true_goal_rank", "std_true_goal_probability"]:
        summary_df[col] = summary_df[col].fillna(0.0)
    summary_df = _add_ci_columns(summary_df)
    return raw_df, trial_df, summary_df


# Backwards-compatible alias used by earlier scripts.
def run_beta_sensitivity_experiment(
    planner: BlocksworldAStarPlanner,
    init: State,
    goals: List[CandidateGoal],
    betas: Iterable[float],
    observation_percentages: Iterable[float],
    runs: int = 10,
    seed: int = 7,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw_df, _, summary_df = run_publication_experiment(
        planner=planner,
        init=init,
        goals=goals,
        betas=betas,
        observation_percentages=observation_percentages,
        noise_rates=[0.0],
        noise_modes=["none"],
        runs=runs,
        seed=seed,
    )
    return raw_df, summary_df
