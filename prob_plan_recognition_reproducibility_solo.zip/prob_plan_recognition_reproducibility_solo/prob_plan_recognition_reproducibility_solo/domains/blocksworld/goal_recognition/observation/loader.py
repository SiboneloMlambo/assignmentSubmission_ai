from __future__ import annotations

from pathlib import Path
from typing import List, Tuple

Action = Tuple[str, Tuple[str, ...]]


def parse_action(line: str) -> Action:
    """Parse an action such as '(stack A B)' into ('stack', ('A', 'B'))."""
    line = line.strip()
    if not line or line.startswith("#"):
        raise ValueError("Empty/comment line is not an action")
    line = line.strip("()")
    parts = line.split()
    if not parts:
        raise ValueError(f"Invalid action line: {line!r}")
    return parts[0].lower(), tuple(parts[1:])


def load_observations(path: str | Path) -> List[Action]:
    actions: List[Action] = []
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        raw = raw.strip()
        if not raw or raw.startswith("#"):
            continue
        actions.append(parse_action(raw))
    return actions
