from __future__ import annotations

from dataclasses import dataclass
from math import exp, isinf
from typing import Iterable, List

from goal_recognition.pddl.generator import CandidateGoal
from goal_recognition.pddl.parser import State
from goal_recognition.observation.loader import Action
from goal_recognition.planner.astar_blocksworld import BlocksworldAStarPlanner


@dataclass
class GoalScore:
    goal: CandidateGoal
    optimal_cost: float
    compliant_cost: float
    delta: float
    observation_length: int
    log_likelihood: float
    probability: float = 0.0


class BayesianGoalScorer:
    """Bayesian goal scorer with an explicit beta parameter.

    The reproducibility assignment notes that beta is ambiguous in the original paper,
    so the experiment runner sweeps beta values and reports sensitivity.

    For each goal G, this simplified educational scorer computes:
      C*       = optimal cost from the initial state to G
      C_obs    = cost of the observed prefix + optimal remaining cost to G
      Delta    = C_obs - C*
      P(O|G) ∝ exp(-beta * Delta)

    A uniform prior is used unless the caller supplies candidate goals with external priors.
    """

    def __init__(self, planner: BlocksworldAStarPlanner, beta: float = 1.0):
        if beta <= 0:
            raise ValueError("beta must be positive")
        self.planner = planner
        self.beta = beta

    def score(self, init: State, observations: List[Action], goals: Iterable[CandidateGoal]) -> List[GoalScore]:
        observed_state = self.planner.replay(init, observations)
        if observed_state is None:
            raise ValueError("Observation sequence is not executable from the initial state.")

        raw_scores: List[GoalScore] = []
        obs_cost = len(observations)

        for goal in goals:
            optimal_cost = self.planner.plan_cost(init, goal.facts)
            remaining_cost = self.planner.plan_cost(observed_state, goal.facts)
            compliant_cost = float("inf") if isinf(remaining_cost) else obs_cost + remaining_cost
            delta = compliant_cost - optimal_cost if not (isinf(compliant_cost) or isinf(optimal_cost)) else float("inf")
            log_like = -10**9 if isinf(delta) else -self.beta * delta
            raw_scores.append(
                GoalScore(
                    goal=goal,
                    optimal_cost=optimal_cost,
                    compliant_cost=compliant_cost,
                    delta=delta,
                    observation_length=obs_cost,
                    log_likelihood=log_like,
                )
            )

        finite = [s.log_likelihood for s in raw_scores if s.log_likelihood > -10**8]
        if not finite:
            return raw_scores

        max_ll = max(finite)
        denom = sum(exp(s.log_likelihood - max_ll) for s in raw_scores if s.log_likelihood > -10**8)
        for s in raw_scores:
            s.probability = 0.0 if s.log_likelihood <= -10**8 else exp(s.log_likelihood - max_ll) / denom

        return sorted(raw_scores, key=lambda s: (-s.probability, s.goal.name))
