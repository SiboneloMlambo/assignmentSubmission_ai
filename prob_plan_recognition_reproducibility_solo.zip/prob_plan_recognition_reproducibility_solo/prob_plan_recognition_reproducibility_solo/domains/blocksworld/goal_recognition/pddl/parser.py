from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, FrozenSet, Iterable, List, Tuple

Fact = Tuple[str, Tuple[str, ...]]
State = FrozenSet[Fact]

FACT_RE = re.compile(r"\(([a-zA-Z0-9_-]+)\s*([^()]*)\)")


def parse_fact(text: str) -> Fact:
    text = text.strip().strip("()")
    parts = text.split()
    if not parts:
        raise ValueError(f"Invalid fact: {text!r}")
    return parts[0].lower(), tuple(parts[1:])


def parse_facts(block: str) -> List[Fact]:
    facts: List[Fact] = []
    for name, args in FACT_RE.findall(block):
        if name.lower() in {"and", "not"}:
            continue
        facts.append((name.lower(), tuple(args.split())))
    return facts


def _section(text: str, key: str) -> str:
    idx = text.lower().find(key.lower())
    if idx == -1:
        return ""
    start = text.find("(", idx)
    if start == -1:
        return ""
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return text[start:i+1]
    return ""


def parse_problem(path: str | Path) -> Dict[str, object]:
    text = Path(path).read_text(encoding="utf-8")
    objects_match = re.search(r":objects\s+([^)]*)\)", text, flags=re.IGNORECASE | re.DOTALL)
    objects = tuple(objects_match.group(1).split()) if objects_match else tuple()
    lower = text.lower()
    init_idx = lower.find(":init")
    goal_idx = lower.find(":goal")
    init_block = text[init_idx:goal_idx] if init_idx != -1 and goal_idx != -1 else _section(text, ":init")
    goal_block = _section(text, ":goal")
    init = frozenset(parse_facts(init_block))
    goal = frozenset(parse_facts(goal_block))
    return {"objects": objects, "init": init, "goal": goal}


def fact_to_pddl(fact: Fact) -> str:
    name, args = fact
    return f"({name} {' '.join(args)})" if args else f"({name})"
