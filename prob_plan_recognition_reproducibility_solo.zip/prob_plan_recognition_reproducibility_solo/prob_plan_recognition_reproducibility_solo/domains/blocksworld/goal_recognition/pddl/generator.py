from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations
from typing import FrozenSet, Iterable, List, Tuple

from goal_recognition.pddl.parser import Fact


@dataclass(frozen=True)
class CandidateGoal:
    name: str
    facts: FrozenSet[Fact]


def generate_stack_goals(blocks: Iterable[str], max_goals: int | None = None) -> List[CandidateGoal]:
    """Generate candidate tower goals such as A on B and B on C."""
    block_list = list(blocks)
    goals: List[CandidateGoal] = []
    for order in permutations(block_list):
        facts = []
        for top, bottom in zip(order[:-1], order[1:]):
            facts.append(("on", (top, bottom)))
        name = "stack_" + "_on_".join(order)
        goals.append(CandidateGoal(name=name, facts=frozenset(facts)))
        if max_goals is not None and len(goals) >= max_goals:
            break
    return goals


def default_blocksworld_goals() -> List[CandidateGoal]:
    return generate_stack_goals(["A", "B", "C"])
