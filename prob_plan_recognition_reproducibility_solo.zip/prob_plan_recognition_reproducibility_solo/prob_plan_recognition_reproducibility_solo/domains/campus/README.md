# Campus Goal Recognition — Publication-Level Experiment Repo

This repository is a complete, runnable goal-recognition experiment for a **Campus planning problem**.
It mirrors the Blocksworld/Logistics structure: PDDL domain/problem files, executable observations,
Bayesian goal scoring, beta sensitivity, observation-percentage experiments, noise robustness, CSV outputs,
plots, and a short LaTeX report.

## Scenario

A student starts at the dorm and moves around campus using walking paths and shuttle links. The observer sees a partial or noisy action trace and must infer the student's goal:

- `G1_attend_lab_session`
- `G2_study_at_library`
- `G3_visit_admin_office`
- `G4_get_lunch`
- `G5_go_to_sports_centre`

## Run

```bash
pip install -r requirements.txt
python full_pipeline.py --mode single
python full_pipeline.py --mode publication --runs 50
```

Outputs are written to `outputs/`:

- `publication_raw_candidates.csv`
- `publication_trials.csv`
- `publication_summary.csv`
- `outputs/plots/`

The built-in planner is used by default, so the repo works immediately.
