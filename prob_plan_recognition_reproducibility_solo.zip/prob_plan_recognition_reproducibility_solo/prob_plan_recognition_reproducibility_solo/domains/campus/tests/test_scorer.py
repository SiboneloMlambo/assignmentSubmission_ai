from goal_recognition.bayes.scorer import BayesianGoalScorer
from goal_recognition.pddl.parser import parse_problem
from goal_recognition.pddl.generator import default_campus_goals
from goal_recognition.planner.astar_campus import CampusAStarPlanner

def test_true_lab_goal_scores_top_with_full_observation():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = CampusAStarPlanner(["student1"], ["dorm","quad","library","science","lab","admin","cafeteria","sports"])
    observations = [
        ("walk", ("student1", "dorm", "quad")),
        ("take-shuttle", ("student1", "quad", "science")),
        ("walk", ("student1", "science", "lab")),
    ]
    scores = BayesianGoalScorer(planner, beta=1.0).score(problem["init"], observations, default_campus_goals())
    assert scores[0].goal.name == "G1_attend_lab_session"
