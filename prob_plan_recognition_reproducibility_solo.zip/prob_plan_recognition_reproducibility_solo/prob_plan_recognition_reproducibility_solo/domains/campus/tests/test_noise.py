import random
from goal_recognition.observation.noise import apply_executable_noise
from goal_recognition.pddl.parser import parse_problem
from goal_recognition.planner.astar_campus import CampusAStarPlanner

def test_noise_keeps_trace_executable():
    problem = parse_problem("data/problems/example_problem.pddl")
    planner = CampusAStarPlanner(["student1"], ["dorm","quad","library","science","lab","admin","cafeteria","sports"])
    observations = [
        ("walk", ("student1", "dorm", "quad")),
        ("take-shuttle", ("student1", "quad", "science")),
        ("walk", ("student1", "science", "lab")),
    ]
    noisy = apply_executable_noise(observations, problem["init"], planner, random.Random(3), mode="mixed", rate=0.25)
    assert planner.replay(problem["init"], noisy.observations) is not None
