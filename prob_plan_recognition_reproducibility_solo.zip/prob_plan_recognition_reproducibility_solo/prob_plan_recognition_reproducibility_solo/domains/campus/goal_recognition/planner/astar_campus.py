from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import FrozenSet, Iterable, List, Optional, Set

from goal_recognition.pddl.parser import Fact, State
from goal_recognition.observation.loader import Action


@dataclass(order=True)
class Node:
    priority: int
    cost: int
    state: State = field(compare=False)
    plan: List[Action] = field(compare=False, default_factory=list)


class CampusAStarPlanner:
    """Deterministic campus planner for goal-recognition experiments."""

    def __init__(self, students: Iterable[str], locations: Iterable[str], max_expansions: int = 50000):
        self.students = tuple(students)
        self.locations = tuple(locations)
        self.max_expansions = max_expansions

    def is_goal(self, state: State, goal: FrozenSet[Fact]) -> bool:
        return goal.issubset(state)

    def _student_location(self, state: State, student: str) -> str | None:
        for pred, args in state:
            if pred == "at" and len(args) == 2 and args[0] == student:
                return args[1]
        return None

    def applicable_actions(self, state: State) -> List[Action]:
        actions: List[Action] = []
        for student in self.students:
            cur = self._student_location(state, student)
            if cur is None:
                continue
            for to in self.locations:
                if to == cur:
                    continue
                if ("connected", (cur, to)) in state:
                    actions.append(("walk", (student, cur, to)))
                if ("shuttle-link", (cur, to)) in state:
                    actions.append(("take-shuttle", (student, cur, to)))
        return sorted(actions)

    def apply(self, state: State, action: Action) -> Optional[State]:
        name, args = action
        facts: Set[Fact] = set(state)
        if name == "walk":
            student, frm, to = args
            if ("at", (student, frm)) not in facts or ("connected", (frm, to)) not in facts:
                return None
        elif name == "take-shuttle":
            student, frm, to = args
            if ("at", (student, frm)) not in facts or ("shuttle-link", (frm, to)) not in facts:
                return None
        else:
            return None
        facts.discard(("at", (student, frm)))
        facts.add(("at", (student, to)))
        return frozenset(facts)

    def replay(self, init: State, observations: List[Action]) -> Optional[State]:
        state = init
        for action in observations:
            state = self.apply(state, action)
            if state is None:
                return None
        return state

    def plan(self, init: State, goal: FrozenSet[Fact]) -> Optional[List[Action]]:
        if self.is_goal(init, goal):
            return []
        queue = deque([(init, [])])
        visited = {init}
        expansions = 0
        while queue and expansions < self.max_expansions:
            state, plan = queue.popleft()
            expansions += 1
            for action in self.applicable_actions(state):
                nxt = self.apply(state, action)
                if nxt is None or nxt in visited:
                    continue
                new_plan = plan + [action]
                if self.is_goal(nxt, goal):
                    return new_plan
                visited.add(nxt)
                queue.append((nxt, new_plan))
        return None

    def plan_cost(self, init: State, goal: FrozenSet[Fact]) -> float:
        plan = self.plan(init, goal)
        return float("inf") if plan is None else float(len(plan))
