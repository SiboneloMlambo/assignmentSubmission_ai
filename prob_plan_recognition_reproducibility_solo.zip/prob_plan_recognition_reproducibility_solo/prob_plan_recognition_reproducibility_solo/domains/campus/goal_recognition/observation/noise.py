from __future__ import annotations

import random
from dataclasses import dataclass
from typing import List, Literal, Protocol

from goal_recognition.observation.loader import Action
from goal_recognition.pddl.parser import State

NoiseMode = Literal["none", "missing", "corrupt", "spurious", "mixed"]


class ExecutablePlanner(Protocol):
    def applicable_actions(self, state: State) -> List[Action]: ...
    def apply(self, state: State, action: Action) -> State | None: ...


@dataclass(frozen=True)
class NoiseResult:
    observations: List[Action]
    dropped: int
    corrupted: int
    inserted: int
    original_length: int

    @property
    def noisy_length(self) -> int:
        return len(self.observations)


def _choose_applicable(planner: ExecutablePlanner, state: State, rng: random.Random) -> Action | None:
    actions = planner.applicable_actions(state)
    if not actions:
        return None
    return rng.choice(actions)


def apply_executable_noise(
    observations: List[Action],
    init: State,
    planner: ExecutablePlanner,
    rng: random.Random,
    mode: NoiseMode = "none",
    rate: float = 0.0,
) -> NoiseResult:
    """Add reproducible observation noise while keeping the observation trace executable.

    A naive replacement/insertion can create impossible action traces in Logistics. For the
    reproducibility experiments we therefore inject only actions that are applicable in the
    current simulated state. This gives a controlled robustness test without failing the
    downstream planner/scorer because of syntactically valid but physically impossible traces.

    Modes:
      none      : return the original prefix unchanged.
      missing   : independently drop each observed action with probability ``rate``.
      corrupt   : replace an observed action with a different applicable action with probability ``rate``.
      spurious  : insert an extra applicable action before each observed action with probability ``rate``.
      mixed     : combine missing, corrupt, and spurious at the same rate.
    """
    if not 0.0 <= rate <= 1.0:
        raise ValueError("noise rate must be between 0 and 1")
    if mode == "none" or rate == 0.0:
        return NoiseResult(list(observations), 0, 0, 0, len(observations))

    state = init
    noisy: List[Action] = []
    dropped = corrupted = inserted = 0

    for action in observations:
        if mode in {"spurious", "mixed"} and rng.random() < rate:
            extra = _choose_applicable(planner, state, rng)
            if extra is not None:
                nxt = planner.apply(state, extra)
                if nxt is not None:
                    noisy.append(extra)
                    state = nxt
                    inserted += 1

        if mode in {"missing", "mixed"} and rng.random() < rate:
            dropped += 1
            # The observer missed this action. Because the scorer replays only the
            # observed trace from the initial state, we do not advance the observed
            # state here. Later actions that become impossible are skipped below.
            continue

        action_to_add = action
        if mode in {"corrupt", "mixed"} and rng.random() < rate:
            candidates = [a for a in planner.applicable_actions(state) if a != action]
            if candidates:
                action_to_add = rng.choice(candidates)
                corrupted += 1

        nxt = planner.apply(state, action_to_add)
        if nxt is None:
            # If earlier noise made the original action impossible, skip it as an additional
            # missing observation rather than crashing the experiment.
            dropped += 1
            continue
        noisy.append(action_to_add)
        state = nxt

    return NoiseResult(noisy, dropped, corrupted, inserted, len(observations))
