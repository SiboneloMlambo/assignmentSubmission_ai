from __future__ import annotations

from dataclasses import dataclass
from typing import FrozenSet, Iterable, List

from goal_recognition.pddl.parser import Fact


@dataclass(frozen=True)
class CandidateGoal:
    name: str
    facts: FrozenSet[Fact]


def generate_destination_goals(student: str, destinations: Iterable[str]) -> List[CandidateGoal]:
    return [CandidateGoal(f"go_to_{d}", frozenset({("at", (student, d))})) for d in destinations]


def default_campus_goals() -> List[CandidateGoal]:
    return [
        CandidateGoal("G1_attend_lab_session", frozenset({("at", ("student1", "lab"))})),
        CandidateGoal("G2_study_at_library", frozenset({("at", ("student1", "library"))})),
        CandidateGoal("G3_visit_admin_office", frozenset({("at", ("student1", "admin"))})),
        CandidateGoal("G4_get_lunch", frozenset({("at", ("student1", "cafeteria"))})),
        CandidateGoal("G5_go_to_sports_centre", frozenset({("at", ("student1", "sports"))})),
    ]
