(define (domain campus)
  (:requirements :strips :typing)
  (:types student location - object)
  (:predicates
    (at ?s - student ?l - location)
    (connected ?from - location ?to - location)
    (shuttle-link ?from - location ?to - location)
  )

  (:action walk
    :parameters (?s - student ?from - location ?to - location)
    :precondition (and (at ?s ?from) (connected ?from ?to))
    :effect (and (not (at ?s ?from)) (at ?s ?to)))

  (:action take-shuttle
    :parameters (?s - student ?from - location ?to - location)
    :precondition (and (at ?s ?from) (shuttle-link ?from ?to))
    :effect (and (not (at ?s ?from)) (at ?s ?to)))
)
