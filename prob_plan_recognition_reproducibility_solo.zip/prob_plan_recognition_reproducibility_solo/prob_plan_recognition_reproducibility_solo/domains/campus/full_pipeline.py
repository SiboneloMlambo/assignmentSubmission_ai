from __future__ import annotations

import argparse
from pathlib import Path

from goal_recognition.bayes.scorer import BayesianGoalScorer
from goal_recognition.experiments.runner import run_publication_experiment, run_single_experiment
from goal_recognition.observation.loader import load_observations
from goal_recognition.pddl.generator import default_campus_goals
from goal_recognition.pddl.parser import parse_problem
from goal_recognition.planner.astar_campus import CampusAStarPlanner
from goal_recognition.planner.fast_downward import FastDownwardPlanner


def parse_float_list(value: str) -> list[float]:
    return [float(x.strip()) for x in value.split(",") if x.strip()]


def parse_str_list(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def build_default_campus_planner() -> CampusAStarPlanner:
    return CampusAStarPlanner(
        students=["student1"],
        locations=["dorm", "quad", "library", "science", "lab", "admin", "cafeteria", "sports"],
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Campus goal recognition reproducibility experiments")
    parser.add_argument("--problem", default="data/problems/example_problem.pddl")
    parser.add_argument("--observations", default="data/observations/example_observations.txt")
    parser.add_argument("--true-goal", default="G1_attend_lab_session")
    parser.add_argument("--fd-path", default=None, help="Optional path to fast-downward.py. Built-in planner is used by default.")
    parser.add_argument("--mode", choices=["single", "publication"], default="publication")
    parser.add_argument("--beta", type=float, default=1.0, help="Beta for single-run scoring")
    parser.add_argument("--betas", default="0.1,0.25,0.5,1,2,5,10")
    parser.add_argument("--observation-percentages", default="0.25,0.5,0.75,1.0")
    parser.add_argument("--noise-rates", default="0,0.1,0.2,0.3")
    parser.add_argument("--noise-modes", default="none,missing,corrupt,spurious,mixed")
    parser.add_argument("--runs", type=int, default=50)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--csv-out", default="outputs/ranked_goals.csv")
    parser.add_argument("--raw-csv-out", default="outputs/publication_raw_candidates.csv")
    parser.add_argument("--trial-csv-out", default="outputs/publication_trials.csv")
    parser.add_argument("--summary-csv-out", default="outputs/publication_summary.csv")
    parser.add_argument("--no-plots", action="store_true")
    args = parser.parse_args()

    problem = parse_problem(args.problem)
    init = problem["init"]
    goals = default_campus_goals()

    fd = FastDownwardPlanner(args.fd_path)
    if args.fd_path and not fd.available():
        print(f"Warning: Fast Downward not found at {args.fd_path}. Using built-in Logistics planner.")

    planner = build_default_campus_planner()

    if args.mode == "single":
        observations = load_observations(args.observations)
        scorer = BayesianGoalScorer(planner=planner, beta=args.beta)
        result = run_single_experiment(scorer, init, observations, goals, args.true_goal)
        print("\nRanked candidate goals:")
        print(result.table.to_string(index=False))
        print(f"\nPredicted goal: {result.predicted_goal}")
        print(f"True goal:      {result.true_goal}")
        print(f"True rank:      {result.true_goal_rank}")
        print(f"Top-1 correct:  {result.top1_correct}")
        out = Path(args.csv_out)
        out.parent.mkdir(parents=True, exist_ok=True)
        result.table.to_csv(out, index=False)
        print(f"\nSaved ranking to {out}")
        return

    raw_df, trial_df, summary_df = run_publication_experiment(
        planner=planner,
        init=init,
        goals=goals,
        betas=parse_float_list(args.betas),
        observation_percentages=parse_float_list(args.observation_percentages),
        noise_rates=parse_float_list(args.noise_rates),
        noise_modes=parse_str_list(args.noise_modes),
        runs=args.runs,
        seed=args.seed,
    )

    raw_path = Path(args.raw_csv_out)
    trial_path = Path(args.trial_csv_out)
    summary_path = Path(args.summary_csv_out)
    for path in [raw_path, trial_path, summary_path]:
        path.parent.mkdir(parents=True, exist_ok=True)
    raw_df.to_csv(raw_path, index=False)
    trial_df.to_csv(trial_path, index=False)
    summary_df.to_csv(summary_path, index=False)

    print("\nPublication experiment summary:")
    print(summary_df.to_string(index=False))
    print(f"\nSaved candidate-level raw results to {raw_path}")
    print(f"Saved trial-level results to {trial_path}")
    print(f"Saved summary results to {summary_path}")

    if not args.no_plots:
        from goal_recognition.experiments.plots import write_plots
        paths = write_plots(summary_df, output_dir=summary_path.parent / "plots")
        for path in paths:
            print(f"Saved plot to {path}")


if __name__ == "__main__":
    main()
